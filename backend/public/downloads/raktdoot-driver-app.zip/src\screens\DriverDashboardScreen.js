import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  View, Text, StyleSheet, TouchableOpacity,
  ScrollView, Alert, Switch, Platform, ActivityIndicator
} from 'react-native';
import { STATUS_COLORS } from '../config/constants';
import { socketManager } from '../services/socket';
import { createIssue, getDriverIssues } from '../services/api';
import { LocationSimulator } from '../services/locationSimulator';
import { getExactCurrentLocation, startLocationWatcher, requestLocationPermissions } from '../services/realLocation';
import ReportIssueModal from '../components/ReportIssueModal';
import IssuesHistoryModal from '../components/IssuesHistoryModal';

export default function DriverDashboardScreen({
  user,
  token,
  serverUrl,
  onLogout,
}) {
  const [driverStatus, setDriverStatus] = useState('active'); // active, idle, offline
  const [socketConnected, setSocketConnected] = useState(false);
  const [useSimulator, setUseSimulator] = useState(false); // Default to REAL DEVICE GPS
  const [gpsStatus, setGpsStatus] = useState('acquiring'); // acquiring, locked, denied, error
  const [gpsAccuracy, setGpsAccuracy] = useState(null);
  const [gpsErrorMsg, setGpsErrorMsg] = useState('');
  const [isRefreshingGps, setIsRefreshingGps] = useState(false);
  const [currentTelemetry, setCurrentTelemetry] = useState({
    lat: 19.0760,
    lng: 72.8777,
    speed: 0,
    heading: 0,
    address: 'Acquiring Real Device GPS...',
  });
  const [pingsCount, setPingsCount] = useState(0);
  const [lastSyncTime, setLastSyncTime] = useState(new Date());

  // Modals
  const [showReportModal, setShowReportModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [issuesHistory, setIssuesHistory] = useState([]);

  // Simulator & GPS tracking references
  const simulatorRef = useRef(new LocationSimulator());
  const watcherCleanupRef = useRef(null);
  const intervalRef = useRef(null);

  // ── Helper: Stop tracking ──
  const stopTracking = useCallback(() => {
    if (intervalRef.current) {
      clearInterval(intervalRef.current);
      intervalRef.current = null;
    }
    if (watcherCleanupRef.current) {
      watcherCleanupRef.current();
      watcherCleanupRef.current = null;
    }
  }, []);

  // ── Helper: Transmit location packet to backend ──
  const transmitLocation = useCallback((locationData, status) => {
    const payload = {
      lat: locationData.lat,
      lng: locationData.lng,
      speed: locationData.speed || 0,
      heading: locationData.heading || 0,
      status: status || driverStatus,
      address: locationData.address || null,
    };

    setCurrentTelemetry(locationData);
    setLastSyncTime(new Date());
    setPingsCount(prev => prev + 1);

    socketManager.emitLocationUpdate(payload);
  }, [driverStatus]);

  // ── Helper: Start location tracking (Simulator or Real GPS) ──
  const startTracking = useCallback(() => {
    stopTracking();

    if (driverStatus === 'offline') return;

    if (useSimulator) {
      setGpsStatus('simulated');
      // Send first telemetry point immediately!
      const initialPoint = simulatorRef.current.getNextPoint();
      transmitLocation(initialPoint, driverStatus);

      // Periodic simulated driving updates every 3 seconds
      intervalRef.current = setInterval(() => {
        const nextPoint = simulatorRef.current.getNextPoint();
        transmitLocation(nextPoint, driverStatus);
      }, 3000);
    } else {
      // Real Hardware / Browser GPS via realLocation service
      setGpsStatus('acquiring');
      setGpsErrorMsg('');

      const cleanup = startLocationWatcher(
        (location) => {
          setGpsStatus('locked');
          setGpsAccuracy(location.accuracy);
          setGpsErrorMsg('');
          transmitLocation(location, driverStatus);
        },
        (err) => {
          console.warn('[GPS Watcher Error]:', err.message);
          if (err.message.includes('denied') || err.message.includes('permission')) {
            setGpsStatus('denied');
            setGpsErrorMsg('Location access was denied. Please allow GPS permission in your browser/device.');
          } else {
            setGpsStatus('error');
            setGpsErrorMsg(err.message || 'GPS signal unavailable');
          }
        }
      );

      watcherCleanupRef.current = cleanup;
    }
  }, [driverStatus, useSimulator, transmitLocation, stopTracking]);

  // ── Helper: Manual GPS Refresh / Acquire ──
  const handleRefreshExactGps = async () => {
    if (useSimulator) {
      const nextPoint = simulatorRef.current.getNextPoint();
      transmitLocation(nextPoint, driverStatus);
      return;
    }

    setIsRefreshingGps(true);
    setGpsErrorMsg('');
    try {
      const loc = await getExactCurrentLocation();
      setGpsStatus('locked');
      setGpsAccuracy(loc.accuracy);
      transmitLocation(loc, driverStatus);
      if (Platform.OS === 'web') {
        // Light notification on web
        console.log('[GPS Locked]', loc.address);
      } else {
        Alert.alert('GPS Locked', `Accurate location acquired: ${loc.address} (±${loc.accuracy}m)`);
      }
    } catch (err) {
      setGpsStatus('error');
      setGpsErrorMsg(err.message);
      Alert.alert(
        'GPS Acquisition Notice',
        `${err.message}\n\nYou can grant permission or toggle Route Simulator mode below for testing.`,
        [
          { text: 'Switch to Simulator', onPress: () => setUseSimulator(true) },
          { text: 'Retry', onPress: () => handleRefreshExactGps() }
        ]
      );
    } finally {
      setIsRefreshingGps(false);
    }
  };

  // ── Helper: Load issues from REST API ──
  const loadIssues = useCallback(async () => {
    try {
      const data = await getDriverIssues(serverUrl, token);
      setIssuesHistory(data);
    } catch (_) {}
  }, [serverUrl, token]);

  // ── Effect 1: Connect WebSocket on mount ──
  useEffect(() => {
    socketManager.connect(serverUrl, token, (connected) => {
      setSocketConnected(connected);
      if (connected) {
        socketManager.emitStatusChange(driverStatus);
        // Transmit immediate GPS location on connect
        if (driverStatus !== 'offline') {
          if (useSimulator) {
            const pt = simulatorRef.current.getNextPoint();
            transmitLocation(pt, driverStatus);
          } else {
            getExactCurrentLocation()
              .then(loc => {
                setGpsStatus('locked');
                setGpsAccuracy(loc.accuracy);
                transmitLocation(loc, driverStatus);
              })
              .catch(err => {
                console.warn('[GPS Connect Error]', err.message);
              });
          }
        }
      }
    });

    loadIssues();

    return () => {
      stopTracking();
      socketManager.disconnect();
    };
  }, [serverUrl, token, driverStatus, useSimulator, transmitLocation, stopTracking, loadIssues]);

  // ── Effect 2: Restart tracking when status or simulator mode changes ──
  useEffect(() => {
    if (driverStatus !== 'offline') {
      startTracking();
    } else {
      stopTracking();
    }
    return () => stopTracking();
  }, [driverStatus, useSimulator, startTracking, stopTracking]);

  // Handle Shift Status Changes
  const handleStatusChange = (newStatus) => {
    setDriverStatus(newStatus);
    socketManager.emitStatusChange(newStatus);

    if (newStatus === 'offline') {
      stopTracking();
      // Send final offline ping
      transmitLocation({ ...currentTelemetry, speed: 0 }, 'offline');
    } else if (newStatus === 'idle') {
      transmitLocation({ ...currentTelemetry, speed: 0 }, 'idle');
    }
  };

  // Handle Issue Submission
  const handleReportIssue = async (issueData) => {
    // 1. Submit via REST API
    const created = await createIssue(serverUrl, token, issueData);

    // 2. Emit real-time WebSocket alert
    socketManager.emitIssueReported({
      ...created,
      driver_name: user?.name,
    });

    // 3. Update status to issue
    setDriverStatus('issue');
    socketManager.emitStatusChange('issue');

    // Refresh history
    setIssuesHistory(prev => [created, ...prev]);

    Alert.alert(
      'Alert Dispatched',
      'Your incident has been transmitted live to the manager console.'
    );
  };

  const initials = user?.name
    ? user.name.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()
    : 'DR';

  return (
    <View style={styles.container}>
      {/* Top App Bar */}
      <View style={styles.topbar}>
        <View style={styles.driverProfile}>
          <View style={[styles.avatar, { backgroundColor: user?.avatar_color || '#6366f1' }]}>
            <Text style={styles.avatarText}>{initials}</Text>
          </View>
          <View>
            <Text style={styles.driverName}>{user?.name || 'Delivery Driver'}</Text>
            <View style={styles.socketIndicator}>
              <View style={[styles.dot, { backgroundColor: socketConnected ? '#10b981' : '#ef4444' }]} />
              <Text style={styles.socketText}>
                {socketConnected ? 'Connected (Live)' : 'Reconnecting...'}
              </Text>
            </View>
          </View>
        </View>

        <TouchableOpacity onPress={onLogout} style={styles.logoutBtn}>
          <Text style={styles.logoutText}>Exit</Text>
        </TouchableOpacity>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        {/* Shift Control Card */}
        <View style={styles.shiftCard}>
          <View style={styles.shiftHeader}>
            <Text style={styles.shiftCardTitle}>Shift Status</Text>
            <View style={[styles.statusPill, { backgroundColor: `${STATUS_COLORS[driverStatus]}22`, borderColor: STATUS_COLORS[driverStatus] }]}>
              <View style={[styles.statusDot, { backgroundColor: STATUS_COLORS[driverStatus] }]} />
              <Text style={[styles.statusPillText, { color: STATUS_COLORS[driverStatus] }]}>
                {driverStatus.toUpperCase()}
              </Text>
            </View>
          </View>

          {/* Shift Buttons */}
          <View style={styles.shiftButtonsRow}>
            <TouchableOpacity
              style={[styles.shiftBtn, driverStatus === 'active' && styles.shiftBtnActive]}
              onPress={() => handleStatusChange('active')}
            >
              <Text style={styles.shiftBtnEmoji}>🚚</Text>
              <Text style={[styles.shiftBtnLabel, driverStatus === 'active' && styles.shiftBtnLabelActive]}>
                Online
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.shiftBtn, driverStatus === 'idle' && styles.shiftBtnIdle]}
              onPress={() => handleStatusChange('idle')}
            >
              <Text style={styles.shiftBtnEmoji}>⏸️</Text>
              <Text style={[styles.shiftBtnLabel, driverStatus === 'idle' && { color: '#f59e0b', fontWeight: '700' }]}>
                Break
              </Text>
            </TouchableOpacity>

            <TouchableOpacity
              style={[styles.shiftBtn, driverStatus === 'offline' && styles.shiftBtnOffline]}
              onPress={() => handleStatusChange('offline')}
            >
              <Text style={styles.shiftBtnEmoji}>🛑</Text>
              <Text style={[styles.shiftBtnLabel, driverStatus === 'offline' && { color: '#94a3b8', fontWeight: '700' }]}>
                Off Duty
              </Text>
            </TouchableOpacity>
          </View>
        </View>

        {/* Live Telemetry HUD */}
        <View style={styles.hudCard}>
          <View style={styles.hudHeader}>
            <Text style={styles.hudTitle}>Live Vehicle Telemetry</Text>
            {useSimulator ? (
              <View style={[styles.gpsBadge, { backgroundColor: '#f59e0b22', borderColor: '#f59e0b' }]}>
                <Text style={[styles.gpsBadgeText, { color: '#f59e0b' }]}>🎮 Demo Simulator</Text>
              </View>
            ) : gpsStatus === 'locked' ? (
              <View style={[styles.gpsBadge, { backgroundColor: '#10b98122', borderColor: '#10b981' }]}>
                <View style={[styles.statusDot, { backgroundColor: '#10b981' }]} />
                <Text style={[styles.gpsBadgeText, { color: '#10b981' }]}>
                  GPS Locked {gpsAccuracy ? `(±${gpsAccuracy}m)` : ''}
                </Text>
              </View>
            ) : gpsStatus === 'denied' ? (
              <View style={[styles.gpsBadge, { backgroundColor: '#ef444422', borderColor: '#ef4444' }]}>
                <Text style={[styles.gpsBadgeText, { color: '#ef4444' }]}>⚠️ Permission Denied</Text>
              </View>
            ) : (
              <View style={[styles.gpsBadge, { backgroundColor: '#6366f122', borderColor: '#6366f1' }]}>
                <ActivityIndicator size="small" color="#818cf8" style={{ transform: [{ scale: 0.7 }] }} />
                <Text style={[styles.gpsBadgeText, { color: '#818cf8' }]}>Acquiring GPS...</Text>
              </View>
            )}
          </View>

          {/* Location Permission Denied Alert Card */}
          {gpsStatus === 'denied' && !useSimulator && (
            <View style={styles.gpsDeniedBox}>
              <Text style={styles.gpsDeniedTitle}>📍 Location Access Required</Text>
              <Text style={styles.gpsDeniedText}>
                {gpsErrorMsg || 'Browser or device GPS permission is blocked. Please allow location access in your browser address bar (lock icon) to transmit your real position.'}
              </Text>
              <View style={{ flexDirection: 'row', gap: 8, marginTop: 8 }}>
                <TouchableOpacity
                  style={[styles.smallActionBtn, { backgroundColor: '#4f46e5' }]}
                  onPress={handleRefreshExactGps}
                >
                  <Text style={styles.smallActionBtnText}>Retry Permission</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[styles.smallActionBtn, { backgroundColor: '#334155' }]}
                  onPress={() => setUseSimulator(true)}
                >
                  <Text style={styles.smallActionBtnText}>Use Simulator Instead</Text>
                </TouchableOpacity>
              </View>
            </View>
          )}

          <View style={styles.hudGrid}>
            {/* Speedometer */}
            <View style={styles.hudTile}>
              <Text style={styles.tileLabel}>SPEED</Text>
              <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 4 }}>
                <Text style={styles.speedValue}>{Math.round(currentTelemetry.speed)}</Text>
                <Text style={styles.unitText}>km/h</Text>
              </View>
            </View>

            {/* Compass / Heading */}
            <View style={styles.hudTile}>
              <Text style={styles.tileLabel}>HEADING</Text>
              <View style={{ flexDirection: 'row', alignItems: 'baseline', gap: 4 }}>
                <Text style={styles.headingValue}>{currentTelemetry.heading}°</Text>
                <Text style={styles.unitText}>BEARING</Text>
              </View>
            </View>
          </View>

          {/* Coordinates & Physical Address */}
          <View style={styles.routeBox}>
            <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginBottom: 4 }}>
              <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
                <Text style={{ fontSize: 13 }}>📍</Text>
                <Text style={styles.coordsText}>
                  {currentTelemetry.lat ? currentTelemetry.lat.toFixed(5) : '0.00000'}, {currentTelemetry.lng ? currentTelemetry.lng.toFixed(5) : '0.00000'}
                </Text>
              </View>
              <View style={styles.liveTag}>
                <Text style={styles.liveTagText}>EXACT GPS</Text>
              </View>
            </View>
            <Text style={styles.addressText} numberOfLines={2}>
              {currentTelemetry.address || 'Resolving physical location...'}
            </Text>
          </View>

          {/* Quick Tactile GPS Refresh Button */}
          <TouchableOpacity
            style={[styles.refreshGpsBtn, isRefreshingGps && { opacity: 0.7 }]}
            onPress={handleRefreshExactGps}
            disabled={isRefreshingGps}
          >
            {isRefreshingGps ? (
              <ActivityIndicator size="small" color="#ffffff" style={{ marginRight: 8 }} />
            ) : (
              <Text style={{ fontSize: 15, marginRight: 6 }}>🎯</Text>
            )}
            <Text style={styles.refreshGpsBtnText}>
              {isRefreshingGps ? 'Locking Real Physical GPS...' : 'Acquire / Refresh Exact GPS'}
            </Text>
          </TouchableOpacity>

          {/* Pings & Sync */}
          <View style={styles.metaRow}>
            <Text style={styles.metaLabel}>Telemetry Packets Sent: <Text style={{ color: '#818cf8', fontWeight: '700' }}>{pingsCount}</Text></Text>
            <Text style={styles.metaLabel}>Synced: {lastSyncTime.toLocaleTimeString()}</Text>
          </View>
        </View>

        {/* GPS Tracking Mode Toggle */}
        <View style={styles.simulatorCard}>
          <View style={{ flex: 1, marginRight: 12 }}>
            <Text style={styles.simulatorTitle}>Route Simulation Mode (Demo Only)</Text>
            <Text style={styles.simulatorSub}>
              {useSimulator
                ? 'Simulating realistic Mumbai logistics driving (Bandra ➔ Andheri ➔ BKC)'
                : 'Using real hardware / browser GPS sensor at your actual location'}
            </Text>
          </View>
          <Switch
            value={useSimulator}
            onValueChange={setUseSimulator}
            trackColor={{ false: '#334155', true: '#4f46e5' }}
            thumbColor={useSimulator ? '#818cf8' : '#94a3b8'}
          />
        </View>

        {/* Action Buttons */}
        <View style={styles.actionsContainer}>
          {/* Emergency / Breakdown Alert Button */}
          <TouchableOpacity
            style={styles.emergencyBtn}
            onPress={() => setShowReportModal(true)}
          >
            <Text style={{ fontSize: 20, marginRight: 8 }}>🚨</Text>
            <Text style={styles.emergencyBtnText}>Report Breakdown / Delay</Text>
          </TouchableOpacity>

          {/* Incident Log Button */}
          <TouchableOpacity
            style={styles.historyBtn}
            onPress={() => setShowHistoryModal(true)}
          >
            <Text style={{ fontSize: 16, marginRight: 8 }}>📋</Text>
            <Text style={styles.historyBtnText}>My Incident Logs ({issuesHistory.length})</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>

      {/* Incident Modals */}
      <ReportIssueModal
        visible={showReportModal}
        onClose={() => setShowReportModal(false)}
        onSubmit={handleReportIssue}
        currentLocation={currentTelemetry}
      />

      <IssuesHistoryModal
        visible={showHistoryModal}
        onClose={() => setShowHistoryModal(false)}
        issues={issuesHistory}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#0a0b10',
  },
  topbar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingTop: Platform.OS === 'ios' ? 54 : 36,
    paddingBottom: 14,
    backgroundColor: '#161822',
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255, 255, 255, 0.08)',
  },
  driverProfile: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  avatar: {
    width: 42,
    height: 42,
    borderRadius: 12,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 4,
    elevation: 3,
  },
  avatarText: {
    color: 'white',
    fontSize: 15,
    fontWeight: '800',
  },
  driverName: {
    color: '#f8fafc',
    fontSize: 15,
    fontWeight: '700',
  },
  socketIndicator: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginTop: 2,
  },
  dot: {
    width: 7,
    height: 7,
    borderRadius: 4,
  },
  socketText: {
    color: '#94a3b8',
    fontSize: 11,
    fontWeight: '500',
  },
  logoutBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    backgroundColor: 'rgba(255, 255, 255, 0.06)',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.1)',
  },
  logoutText: {
    color: '#94a3b8',
    fontSize: 12,
    fontWeight: '600',
  },
  scrollContent: {
    padding: 16,
    paddingBottom: 40,
    gap: 14,
  },
  shiftCard: {
    backgroundColor: '#161822',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.08)',
  },
  shiftHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 14,
  },
  shiftCardTitle: {
    color: '#f8fafc',
    fontSize: 14,
    fontWeight: '700',
  },
  statusPill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 14,
    borderWidth: 1,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  statusPillText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  shiftButtonsRow: {
    flexDirection: 'row',
    gap: 8,
  },
  shiftBtn: {
    flex: 1,
    backgroundColor: '#0f111a',
    borderRadius: 12,
    paddingVertical: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.08)',
  },
  shiftBtnActive: {
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    borderColor: '#10b981',
  },
  shiftBtnIdle: {
    backgroundColor: 'rgba(245, 158, 11, 0.15)',
    borderColor: '#f59e0b',
  },
  shiftBtnOffline: {
    backgroundColor: 'rgba(107, 114, 128, 0.15)',
    borderColor: '#6b7280',
  },
  shiftBtnEmoji: {
    fontSize: 20,
    marginBottom: 4,
  },
  shiftBtnLabel: {
    fontSize: 12,
    color: '#94a3b8',
    fontWeight: '600',
  },
  shiftBtnLabelActive: {
    color: '#34d399',
    fontWeight: '700',
  },
  hudCard: {
    backgroundColor: '#161822',
    borderRadius: 16,
    padding: 16,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.08)',
  },
  hudTitle: {
    color: '#f8fafc',
    fontSize: 14,
    fontWeight: '700',
    marginBottom: 12,
  },
  hudGrid: {
    flexDirection: 'row',
    gap: 10,
    marginBottom: 12,
  },
  hudTile: {
    flex: 1,
    backgroundColor: '#0f111a',
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.06)',
  },
  tileLabel: {
    color: '#64748b',
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.5,
    marginBottom: 4,
  },
  speedValue: {
    color: '#38bdf8',
    fontSize: 32,
    fontWeight: '800',
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
  },
  headingValue: {
    color: '#a78bfa',
    fontSize: 32,
    fontWeight: '800',
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
  },
  unitText: {
    color: '#94a3b8',
    fontSize: 11,
    fontWeight: '600',
  },
  routeBox: {
    backgroundColor: '#0f111a',
    borderRadius: 10,
    padding: 12,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.06)',
    marginBottom: 10,
  },
  coordsText: {
    color: '#34d399',
    fontSize: 12,
    fontFamily: Platform.OS === 'ios' ? 'Menlo' : 'monospace',
    fontWeight: '600',
  },
  addressText: {
    color: '#cbd5e1',
    fontSize: 12,
    lineHeight: 16,
  },
  metaRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingTop: 4,
  },
  metaLabel: {
    color: '#64748b',
    fontSize: 11,
  },
  simulatorCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#161822',
    borderRadius: 14,
    padding: 14,
    borderWidth: 1,
    borderColor: 'rgba(99, 102, 241, 0.25)',
  },
  simulatorTitle: {
    color: '#c7d2fe',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 2,
  },
  simulatorSub: {
    color: '#94a3b8',
    fontSize: 11,
    lineHeight: 15,
  },
  actionsContainer: {
    gap: 10,
    marginTop: 6,
  },
  emergencyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#ef4444',
    borderRadius: 14,
    paddingVertical: 15,
    shadowColor: '#ef4444',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 10,
    elevation: 4,
  },
  emergencyBtnText: {
    color: 'white',
    fontSize: 15,
    fontWeight: '700',
  },
  historyBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#161822',
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.12)',
    borderRadius: 14,
    paddingVertical: 13,
  },
  historyBtnText: {
    color: '#cbd5e1',
    fontSize: 14,
    fontWeight: '600',
  },
  hudHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  gpsBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    borderWidth: 1,
  },
  gpsBadgeText: {
    fontSize: 11,
    fontWeight: '700',
  },
  gpsDeniedBox: {
    backgroundColor: 'rgba(239, 68, 68, 0.12)',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.35)',
    borderRadius: 10,
    padding: 12,
    marginBottom: 12,
  },
  gpsDeniedTitle: {
    color: '#ef4444',
    fontSize: 13,
    fontWeight: '700',
    marginBottom: 4,
  },
  gpsDeniedText: {
    color: '#fca5a5',
    fontSize: 11,
    lineHeight: 16,
  },
  smallActionBtn: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  smallActionBtnText: {
    color: 'white',
    fontSize: 11,
    fontWeight: '700',
  },
  liveTag: {
    backgroundColor: 'rgba(16, 185, 129, 0.15)',
    borderColor: '#10b981',
    borderWidth: 1,
    borderRadius: 6,
    paddingHorizontal: 6,
    paddingVertical: 2,
  },
  liveTagText: {
    color: '#10b981',
    fontSize: 9,
    fontWeight: '800',
    letterSpacing: 0.5,
  },
  refreshGpsBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: '#4f46e5',
    borderRadius: 10,
    paddingVertical: 10,
    paddingHorizontal: 14,
    marginBottom: 10,
    shadowColor: '#4f46e5',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3,
    shadowRadius: 6,
    elevation: 3,
  },
  refreshGpsBtnText: {
    color: 'white',
    fontSize: 13,
    fontWeight: '700',
  },
});

